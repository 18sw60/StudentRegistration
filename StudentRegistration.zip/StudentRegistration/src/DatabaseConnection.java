
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author NIKASH
 */
public class DatabaseConnection {
    
   static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";  
   static final String DB_URL = "jdbc:mysql://localhost/StudentRegistration";

   //  Database credentials
    final static String USER = "root";
    final static String PASS = "";
   
   public static Connection connection() throws SQLException 
   {

   try{
      //STEP 2: Register JDBC driver
      Class.forName(JDBC_DRIVER);
      //STEP 3: Open a connection
      Connection conn = DriverManager.getConnection(DB_URL,USER,PASS);
      return conn;
      }
   catch(ClassNotFoundException | SQLException e)
     {
        
                JOptionPane.showMessageDialog(null,e);
                return null;
     }
   }  

   }
   